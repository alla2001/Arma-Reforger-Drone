enum SCR_CustomDroneECharacterDistanceMeasurementMethod
{
	FROM_EYES = 0,
	FROM_ORIGIN,
	FROM_CENTER_OF_MASS,
	FROM_ORIGIN_WITH_OFFSET
}
